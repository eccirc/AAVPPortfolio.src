# 3D_bouncing_ball_beats
playful algorithmic drum machine

Created with openFrameworks https://openframeworks.cc/
and the Maximillian addon https://github.com/micknoise/Maximilian

Written on linux with Qt creator
