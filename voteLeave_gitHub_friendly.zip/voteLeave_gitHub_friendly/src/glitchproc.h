#ifndef GLITCHPROC_H
#define GLITCHPROC_H

#include "ofMain.h"


class GlitchProc
{
public:
    GlitchProc();
    //Custom image/video processing functions
    ofPixels frameThreshDelay(int w, int h, int channels, int thresh, ofPixels _in, ofPixels _out);
    ofPixels glitchThresh(int w, int h, int channels,float thresh, float glitchSoure, ofPixels _in, ofPixels _out);
    ofPixels waveDistort(int w, int h, int channels,ofPixels _in, ofPixels _out, float noiseScale,float noiseMult, float noisePos,float vMult, float rAmt, float gAmt, float bAmt);


    //optional parameter to feed into the above
    float glitchIn;

};

#endif // GLITCHPROC_H
