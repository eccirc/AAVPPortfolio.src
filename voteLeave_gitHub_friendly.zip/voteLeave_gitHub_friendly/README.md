# voteLeave
Experimental audio/visual piece with custom video manipulation

Created with openFrameworks https://openframeworks.cc/
and Maximilliam https://github.com/micknoise/Maximilian

Written on linux with Qt creator
