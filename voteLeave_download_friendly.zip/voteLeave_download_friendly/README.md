# ./voteLeave
Experimental audio/visual piece with custom video manipulation

Created with openFrameworks https://openframeworks.cc/

and Maximilliam https://github.com/micknoise/Maximilian

Written on linux with Qt creator

**COMPILE INSTRUCTIONS**

To run this program, you will need to install open frameworks (see above)

for your operating system of choice and include the ofxMaxim add-on.

Run the project generator to configure with your editor of choice,

then copy over the contents of the 'src' folder. Also check that your editor

includes the additional 'glitchproc.cpp'and'glitchproc.h' files.

To load videos and images, place these in the /bin/data folder of your project.

**NOTE FOR .ZIP VERSION**

To reduce the file size for the .zip file, the original video footage and images of the 

'./votLeave' piece have not been included. If you wish to include these, they can

be obtained from the github repo at https://github.com/eccirc/voteLeave 
