#pragma once

#include "ofMain.h"
#include "ofxMaxim.h"
#include "glitchproc.h"


class ofApp : public ofBaseApp{

public:
    void setup();
    void update();
    void draw();
    void keyPressed(int key);

    //These are the necessary's for setting up Maxim in OF
    //This is the setup for OF 0.10.0 (See 'Sound' exaples in the examples directory for more detailed setup
            void audioOut(ofSoundBuffer &outBuffer);
            //setup ofSoundStream
            ofSoundStream soundStream;
            //ofSoundBuffer lastBuffer;


/*Some basic Maxim objects:  maxiOsc osc; maxiFilter filter; maxiClock clock; maxiEnv env; maxiSample sample*/
    //PUT MAXIM OBJECTS HERE
    //a number of oscillators to produce/control various sounds
    maxiOsc carrier1, carrier2,carrier3, kickOsc, LFO;
    maxiOsc mod1,mod2,mod3,mod4, kickMod;
    maxiOsc modAmt1, modAmt2, modAmt3, modAmt4, modAmt5, modAmt6, modAmt7;

    maxiOsc counter, counter2, LFOphasor, Kickphasor, filterPhasor;

    maxiFilter filter1;
    maxiFilter filter2;
    double filter1Out, filter2Out;

    double out1, out2, out3, kickOut, LFOout, mixOut;

    int LFOcounter, kickCounter;

    int kArray[4] = {1,2,3,4};
    int LFOarray[4] = {1,1,2,2};

    //notes sequence
    int midiNotes[6] = {40,42,43,47,43,42};

    //get RMS
    float sum;
    float RMS = 0;

    //video stuff

    //for debugging
   // ofVideoGrabber wCam;

    //apparently GStreamer can only handle 6 vids at a time...
    ofVideoPlayer vid1;
    ofVideoPlayer vid2;
    ofVideoPlayer vid3;
    ofVideoPlayer vid4;
    ofVideoPlayer vid5;
    ofVideoPlayer vid6;

    ofPixels pixIn1, pixIn2;
    ofPixels pixOut1, pixOut2;

    ofTexture tex1, tex2;

    GlitchProc fx;

    int width, height;

    double drawOutBuffer[512];

    double soundSource;

    //image sequence

    vector<ofImage> images;

    //token trump pic
    ofImage trump;

    //flick through the images with a counter oscillator casting to an integer
    int counterOut;

    float vidMod;

    //scene managing (4 total in this case)
    int scene[4];
    int sceneCounter;




};
