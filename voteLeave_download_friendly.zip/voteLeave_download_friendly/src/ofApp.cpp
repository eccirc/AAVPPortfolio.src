/*This is an experimental audio-visual piece inspired by current events in the world and expecially the UK at this time.
 * All of the images and footage were taken by myself with the exception of the sheep footage by Natalia Janula(https://nataliajanula.com/)
 * and the image of the current US president (https://www.thenation.com/wp-content/uploads/2017/11/Donald-Trump-big-mouth-img.jpg?scale=896&compress=80)
 *
 * The program may of course be run with any video sources compatible with openFrameworks.
 *
 * Custom image manipulation program written by myself with the help of Mick Grierson's AAVP class
 * and audio created with Maximillian https://github.com/micknoise/Maximilian
 *
 * David Williams January 2019
 */


#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    ofSetFrameRate(20);
    //video setup

    vid1.load("videos/#1");
    vid2.load("videos/#2");
    vid3.load("videos/#3");
    vid4.load("videos/#4");
    vid5.load("videos/#5");
    vid6.load("videos/#6");

    //start with first scene
    sceneCounter = 0;

    //match width and height to the dimensions of the videos (mine have all been resized to smaller dimensions in order to speed up the program)
    width = 384;
    height = 288;
    //allocate some memory
    pixIn1.allocate(width, height, 3);
    pixOut1.allocate(width, height, 3);
    pixIn2.allocate(width,height, 3);
    pixOut2.allocate(width,height,3);

    tex1.allocate(width, height, GL_RGB);

    //image sequence
    for(int i = 0; i < 6; i ++){
        ofImage temp;
        images.push_back(temp);
    }
    //load and resize to program standard
    images[0].load("images/img1.JPG");
    images[0].resize(width,height);
    images[1].load("images/img3.JPG");
    images[1].resize(width,height);
    images[2].load("images/img4.JPG");
    images[2].resize(width,height);
    images[3].load("images/img5.JPG");
    images[3].resize(width,height);
    images[4].load("images/img6.JPG");
    images[4].resize(width,height);
    images[5].load("images/img7.JPG");
    images[5].resize(width,height);
    trump.load("images/img8.jpeg");
    trump.resize(width,height);



    //load sample etc. before setting up soundcard

    //This is the necessary audio setup stuff for running Maxim with OF

    //Get and print a list of possible output devices

    auto devices = soundStream.getDeviceList();

    cout << devices << endl;


    //This is the working setup for OF 0.10.0
    ofSoundStreamSettings settings;

    settings.numOutputChannels = 2;
    settings.numInputChannels = 0;
    settings.sampleRate = 44100;
    settings.bufferSize = 512;
    settings.numBuffers = 2;
    settings.setOutListener(this);
    settings.setOutDevice(devices[5]);
    soundStream.setup(settings);



}
//--------------------------------------------------------------
void ofApp::update(){

//update the vidz
vid1.update();
vid2.update();
vid3.update();
vid4.update();
vid5.update();
vid6.update();

    if(vid1.isFrameNew()){

        //scene managing (this could probably be cleaned up)
        if(sceneCounter == 0){
            vid1.play();
            vid2.play();

            pixIn1 = vid1.getPixels();
            pixIn2 = vid2.getPixels();

            vidMod += 0.025;

            float vidThresh = ofMap(sin(vidMod), - 1, 1, 0 , 255);

            pixOut1 = fx.frameThreshDelay(width,height,3, vidThresh ,pixIn1,pixIn2);
            pixOut2 = fx.waveDistort(width,height,3,pixOut1,pixOut2, mixOut * 0.5 ,0.00001,0,0, 0.4,0.5,0.6);
        }
        if(sceneCounter == 1){
            vid3.play();
            vid4.play();

            pixIn1 = vid3.getPixels();
            pixIn2 = vid4.getPixels();

            pixOut1 = fx.frameThreshDelay(width,height,3, 150, pixIn1, pixIn2);
            pixOut2 = fx.glitchThresh(width,height,3, modAmt2.phasor(0.1, 0 , 255), mixOut * 10, pixOut1, pixOut2);
        }
        if(sceneCounter == 2){

            pixIn1 = images[counterOut].getPixels();
            pixIn2 = fx.waveDistort(width,height,3,trump.getPixels(), pixIn1,0.1,0.001,ofGetFrameNum(),0.001, 0.3,0.5,0.6);

            vidMod += 0.2;

            if(vidMod >= 255){
                vidMod = 0;
            }

            pixOut1 = fx.frameThreshDelay(width,height,3,255 - vidMod,pixIn1,pixIn2);
            pixOut2 = fx.glitchThresh(width,height,3,255 - vidMod, mixOut, pixOut1, pixOut2);

        }
        if(sceneCounter == 3){
            vid5.play();
            vid6.play();

            pixIn1 = vid5.getPixels();
            pixIn2 = vid6.getPixels();

            float frameMapThresh1 = ofMap(vid5.getCurrentFrame(), 0, vid5.getTotalNumFrames(), 255, 50, true);
            float frameMapThresh2 = ofMap(vid5.getCurrentFrame(), 0, vid5.getTotalNumFrames(), 255, 0, true);

            //cout << frameMapThresh << endl;

            pixOut1 = fx.frameThreshDelay(width,height,3,frameMapThresh1,pixIn1, pixIn2);
            pixOut2 = fx.glitchThresh(width,height,3,frameMapThresh2,RMS,pixOut1,pixOut2);

            cout << frameMapThresh2 << endl;

        }

    }
    tex1.allocate(pixOut2);

}

//--------------------------------------------------------------
void ofApp::draw(){

    //draw the texture
    tex1.draw(0,0, ofGetWidth(), ofGetHeight());

    //keep track of the time/scene
    //cout << ofGetElapsedTimef() <<"  " << sceneCounter << endl;


}
void ofApp::audioOut(ofSoundBuffer &outBuffer){

//initalise sum to zero at the start of each loop otherwise it will just keep growing
    sum = 0;

    //Put all sound related code within this for loop (This setup for OF 0.10.0)
    for(size_t i = 0; i < outBuffer.getNumFrames(); i ++){


        //easy MIDI to frequency conversion
        convert mtof;

        //Scene audio managing

        //part#1
        if(sceneCounter == 0){
            float freq = mtof.mtof(10);
            out1 = carrier1.sinewave(freq + (mod1.triangle(freq + (mod2.sawn(freq + (mod3.triangle(freq)*500))*500))*modAmt1.phasor(0.1,0,1000)));
            mixOut = out1 * 0.4;
        }
        //part#2
        if(sceneCounter == 1){
            float freq = mtof.mtof(40);
            out1 = carrier1.sinewave(freq + (mod1.triangle(freq + (mod2.sawn(freq + (mod3.triangle(freq)*500))*500))*modAmt2.phasor(0.1,0,1000)));
            mixOut = out1 * 0.4;
        }
        //part#3
        if(sceneCounter == 2){
            //for looping through images/sounds
            counterOut = int(counter.phasor(counter2.phasor(0.01,0.01,2), 0, 6));
            int midiNum = midiNotes[counterOut];
            out1 = carrier1.triangle(mtof.mtof(midiNum) + (mod1.triangle(mtof.mtof(midiNum + 25))*modAmt3.phasor(0.01,0,500)));
            out2 = carrier2.sawn(mtof.mtof(midiNotes[0] + 12) + (mod2.square(mtof.mtof(midiNotes[0]+48))*modAmt4.phasor(0.01,0,500)));
            mixOut = (out1 + out2*0.2) * 0.4;

        }
        //part#4
        if(sceneCounter == 3){
            LFOcounter = LFOphasor.phasor(0.2,0,4);
            LFOout = LFO.sinewave(LFOarray[LFOcounter]);
            //a nice deep FM grindy so8nd - double modulators!
            out3 = carrier3.sinewave(80 + (mod3.sawn(80 + (mod4.sawn(800)*modAmt3.phasor(0.4,80,160)))*LFOout*modAmt5.phasor(0.2,0,3000)));
            //create a kick drum type effect
            kickCounter = Kickphasor.phasor(0.2, 0, 3);
            kickOut = kickOsc.triangle(40 + ((kickMod.sawn(kArray[kickCounter])*100)));
            //fade in the sounds with lopass filters
            filter1Out = filter1.lopass(out3, (LFOout + 1)/2) * modAmt6.phasor(0.002,0,1);
            filter2Out = filter2.lopass(kickOut, filterPhasor.phasor(0.001, 0, 0.6));
            mixOut = (filter1Out + filter2Out) * 0.4;

            sum += (filter2Out * 2)  * (filter2Out  * 2);
            //basic RMS
            RMS = sqrt(sum);
        }


        //These are the audio stereo outs
        outBuffer.getSample(i, 0) = mixOut;
        outBuffer.getSample(i, 1) = mixOut;

        drawOutBuffer[i] = mixOut;

        soundSource = drawOutBuffer[i] * 10;




    }

}
void ofApp::keyPressed(int key){

    //advance the scence
    if(key == OF_KEY_RIGHT){
        sceneCounter ++;
    }
    if(key == OF_KEY_LEFT){
        sceneCounter --;
    }

}

