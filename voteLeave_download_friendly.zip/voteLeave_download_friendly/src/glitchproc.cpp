//Custom image/video manipulation functions drawing on examples from Mick Grierson's Advanced Audio Visual class


#include "glitchproc.h"

GlitchProc::GlitchProc()
{

}

//Switch between either the same video stream or two seperate ones using a basic brightness threshold
ofPixels GlitchProc::frameThreshDelay(int w, int h, int channels, int thresh, ofPixels _in, ofPixels _out){
    int totalSize = w * h * channels;

    for(int i = 0; i < totalSize; i ++){
        //get rgb values
        int r = _in[i + 0];
        int g = _in[i + 1];
        int b = _in[i + 2];
        //simple greyscale
        int av = (r + g + b) / channels;
        //uncomment for b/w
        //_in[i] = av;
        if(av > thresh){
            _out[av] = _in[av] - _in[av];
        }
        else{
            _out[i] = _in[i];
        }
    }


    return _out;
}
//similar to above but glitches the pixels of a given video stream with audio (or other) input
ofPixels GlitchProc::glitchThresh(int w, int h, int channels,float thresh, float glitchSoure, ofPixels _in, ofPixels _out){
    int totalSize = w * h * channels;



    for(int i = 0; i < totalSize; i ++){
        //get rgb values
        int r = _in[i + 0];
        int g = _in[i + 1];
        int b = _in[i + 2];
        //simple greyscale
        int av = (r + g + b) / channels;
        //uncomment for b/w
        //_in[i] = av;
        //glitch out that thresholding using some sort of other input(e.g sound input)
        if(av > thresh){
            _out[i] = _in[i + glitchSoure] - _in[i - glitchSoure];
        }
        else{
            _out[i] = _in[i];
        }

    }

    return _out;
}

//based on Mick Griersons 'resizeX' function, but this used openFrameworks built in perlin noise funtion to to some nice wobbling
ofPixels GlitchProc::waveDistort(int w, int h, int channels,ofPixels _in, ofPixels _out, float noiseScale,float noiseMult, float noisePos,float vMult, float rAmt, float gAmt, float bAmt){
    int totalSize = w * h * channels;

    for(int i = 0; i < totalSize; i += w*channels){
        for(int j = 0; j < w; j ++){
            float noise = ofNoise(noisePos + i * noiseMult, j * vMult) * noiseScale;

            float noiseEffect = noise + 4;

            _out[i +(j * 3) + 0] = _in[i + (floor(j * noiseEffect * rAmt)) + 0];
            _out[i +(j * 3) + 1] = _in[i + (floor(j * noiseEffect * gAmt)) + 1];
            _out[i +(j * 3) + 2] = _in[i + (floor(j * noiseEffect * bAmt)) + 2];
        }
    }
    return _out;

}
