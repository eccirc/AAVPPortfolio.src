# qwerty_drum_machine
simple drum machine with keyboard input

Created with openFrameworks https://openframeworks.cc/
and Maximillian https://github.com/micknoise/Maximilian

Written on linux with Qt creator
