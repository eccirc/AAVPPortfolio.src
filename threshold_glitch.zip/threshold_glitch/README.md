# threshold_glitch
glitchy image/video manipulation program

Created with openFrameworks https://openframeworks.cc/

and Maximilliam https://github.com/micknoise/Maximilian

See example on vimeo: https://vimeo.com/user65273243/review/310777158/9ef677c2a7

Written on linux with Qt creator

**COMPILE INSTRUCTIONS**

To run this program, you will need to install open frameworks (see above)

for your operating system of choice and include the ofxMaxim add-on.

Run the project generator to configure with your editor of choice,

then copy over the contents of the 'src' folder. 
