# noise_ripple
ripple effect image manipulation program

Created with openFrameworks https://openframeworks.cc/

See example on vimeo: https://vimeo.com/user65273243/review/310777225/da9d79de7d

Written on linux with Qt creator

**COMPILE INSTRUCTIONS**

To run this program, you will need to install open frameworks (see above)

for your operating system of choice and include the ofxGui add-on.

Run the project generator to configure with your editor of choice,

then copy over the contents of the 'src' folder. Put image/s to be loaded into

the /bin/data foler of your project.
