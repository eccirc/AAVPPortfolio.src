# noise_ripple
ripple effect image manipulation program

Created with openFrameworks https://openframeworks.cc/

Written on linux with Qt creator
